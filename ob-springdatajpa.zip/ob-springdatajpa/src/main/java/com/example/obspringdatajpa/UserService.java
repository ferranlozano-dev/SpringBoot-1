package com.example.obspringdatajpa;

import org.springframework.stereotype.Component;

@Component

public class UserService {
    //Atributos
    NotificationService notificationService;

    //Constructores
    public UserService() {
        System.out.println("Ejecutando User Service");
    }

    //Métodos
}
