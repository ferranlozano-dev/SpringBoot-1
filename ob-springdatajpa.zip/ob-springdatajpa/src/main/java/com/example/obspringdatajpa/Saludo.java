package com.example.obspringdatajpa;

public class Saludo {
    public String imprimirSaludo() {
        System.err.println("--- Esto es un texto en rojo por consola ---");
        return null;
    }
}
