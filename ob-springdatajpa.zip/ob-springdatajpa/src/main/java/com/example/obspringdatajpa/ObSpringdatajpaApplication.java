package com.example.obspringdatajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class ObSpringdatajpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ObSpringdatajpaApplication.class, args);

        /**EJERCICIO 1*/
        Saludo mostrarSaludoPorPantalla = new Saludo();
        mostrarSaludoPorPantalla.imprimirSaludo();

        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Saludo mostrarSaludo = (Saludo) context.getBean("mostrarSaludo");

        mostrarSaludo.imprimirSaludo();


        /**EJERCICIO 2*/
        Saludo notification = new Saludo();
        notification.imprimirSaludo();

        /**EJERCICIO 3*/
        ApplicationContext context2 = new ClassPathXmlApplicationContext("beans.xml");
        UserService userService = (UserService) context2.getBean("userService");

        System.out.println(userService.notificationService.imprimirSaludoNotification());
    }
}
