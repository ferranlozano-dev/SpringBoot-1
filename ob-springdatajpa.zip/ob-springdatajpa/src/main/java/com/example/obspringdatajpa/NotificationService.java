package com.example.obspringdatajpa;

import org.springframework.stereotype.Component;

@Component
public class NotificationService {
    public String imprimirSaludoNotification() {
        System.out.println("Saludo Notificación Service");
        return null;
    }

}
